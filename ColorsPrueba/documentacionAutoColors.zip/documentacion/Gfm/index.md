//[app](index.md)

# app

## Packages

| Name |
|---|
| [com.example.autocolorsprueba](app/com.example.autocolorsprueba/index.md) |
| [com.example.autocolorsprueba.adapter](app/com.example.autocolorsprueba.adapter/index.md) |
| [com.example.autocolorsprueba.database](app/com.example.autocolorsprueba.database/index.md) |
| [com.example.autocolorsprueba.httpClient](app/com.example.autocolorsprueba.httpClient/index.md) |
| [com.example.autocolorsprueba.model.dao](app/com.example.autocolorsprueba.model.dao/index.md) |
| [com.example.autocolorsprueba.model.entity](app/com.example.autocolorsprueba.model.entity/index.md) |
| [com.example.autocolorsprueba.test](app/com.example.autocolorsprueba.test/index.md) |
