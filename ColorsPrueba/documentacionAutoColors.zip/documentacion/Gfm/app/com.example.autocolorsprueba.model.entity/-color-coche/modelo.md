//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[modelo](modelo.md)

# modelo

[androidJvm]\
val [modelo](modelo.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| modelo | El modelo del coche al que pertenece el color. |
