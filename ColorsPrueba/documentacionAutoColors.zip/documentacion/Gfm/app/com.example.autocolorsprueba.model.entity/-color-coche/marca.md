//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[marca](marca.md)

# marca

[androidJvm]\
val [marca](marca.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| marca | La marca del coche al que pertenece el color. |
