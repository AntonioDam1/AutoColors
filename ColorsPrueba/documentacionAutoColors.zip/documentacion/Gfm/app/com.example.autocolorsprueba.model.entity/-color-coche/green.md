//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[green](green.md)

# green

[androidJvm]\
val [green](green.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| green | El componente verde del color de pintura del coche. |
