//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[red](red.md)

# red

[androidJvm]\
val [red](red.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| red | El componente rojo del color de pintura del coche. |
