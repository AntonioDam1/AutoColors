//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[matchPercentage](match-percentage.md)

# matchPercentage

[androidJvm]\
val [matchPercentage](match-percentage.md): [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| matchPercentage | El porcentaje de coincidencia del color de pintura del coche, puede ser nulo. |
