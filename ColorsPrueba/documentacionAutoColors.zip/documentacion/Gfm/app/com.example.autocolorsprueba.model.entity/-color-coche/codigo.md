//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorCoche](index.md)/[codigo](codigo.md)

# codigo

[androidJvm]\
val [codigo](codigo.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| codigo | El código del color de pintura del coche. |
