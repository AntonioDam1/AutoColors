//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[blue](blue.md)

# blue

[androidJvm]\
val [blue](blue.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| blue | El componente azul del color de pintura del coche favorito. |
