//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[matchPercentage](match-percentage.md)

# matchPercentage

[androidJvm]\
val [matchPercentage](match-percentage.md): [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| matchPercentage | El porcentaje de coincidencia del color de pintura del coche favorito, puede ser nulo. |
