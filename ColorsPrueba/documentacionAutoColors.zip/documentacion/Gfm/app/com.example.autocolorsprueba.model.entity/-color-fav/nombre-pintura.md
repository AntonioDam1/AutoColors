//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[nombrePintura](nombre-pintura.md)

# nombrePintura

[androidJvm]\
val [nombrePintura](nombre-pintura.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| nombrePintura | El nombre del color de pintura del coche favorito. |
