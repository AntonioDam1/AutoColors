//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[uid](uid.md)

# uid

[androidJvm]\
val [uid](uid.md): [Long](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| uid | El identificador único del color favorito del coche. |
