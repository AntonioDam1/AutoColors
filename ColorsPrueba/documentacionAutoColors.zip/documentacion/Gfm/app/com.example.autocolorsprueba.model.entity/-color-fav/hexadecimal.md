//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[hexadecimal](hexadecimal.md)

# hexadecimal

[androidJvm]\
val [hexadecimal](hexadecimal.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| hexadecimal | El valor hexadecimal del color de pintura del coche favorito. |
