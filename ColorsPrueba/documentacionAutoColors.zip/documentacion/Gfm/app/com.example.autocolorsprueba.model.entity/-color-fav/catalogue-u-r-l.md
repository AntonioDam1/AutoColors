//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[catalogueURL](catalogue-u-r-l.md)

# catalogueURL

[androidJvm]\
val [catalogueURL](catalogue-u-r-l.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| catalogueURL | La URL del catálogo del coche favorito. |
