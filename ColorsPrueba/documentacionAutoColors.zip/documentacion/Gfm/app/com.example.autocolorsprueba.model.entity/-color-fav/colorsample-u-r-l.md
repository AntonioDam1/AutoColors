//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[colorsampleURL](colorsample-u-r-l.md)

# colorsampleURL

[androidJvm]\
val [colorsampleURL](colorsample-u-r-l.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| colorsampleURL | La URL de la muestra de color del coche favorito. |
