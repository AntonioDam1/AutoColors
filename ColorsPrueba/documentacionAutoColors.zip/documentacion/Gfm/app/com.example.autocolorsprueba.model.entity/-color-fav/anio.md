//[app](../../../index.md)/[com.example.autocolorsprueba.model.entity](../index.md)/[ColorFav](index.md)/[anio](anio.md)

# anio

[androidJvm]\
val [anio](anio.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)?

#### Parameters

androidJvm

| | |
|---|---|
| anio | El año del coche al que pertenece el color favorito. |
