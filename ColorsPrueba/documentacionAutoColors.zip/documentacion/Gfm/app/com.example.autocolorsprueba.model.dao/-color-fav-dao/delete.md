//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorFavDao](index.md)/[delete](delete.md)

# delete

[androidJvm]\
abstract fun [delete](delete.md)(user: [ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md))

Elimina un color favorito de la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| user | El color favorito que se va a eliminar de la base de datos. |
