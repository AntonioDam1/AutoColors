//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorFavDao](index.md)/[insertAll](insert-all.md)

# insertAll

[androidJvm]\
abstract fun [insertAll](insert-all.md)(vararg users: [ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md))

Inserta uno o más colores favoritos en la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| users | Los colores favoritos que se van a insertar en la base de datos. |
