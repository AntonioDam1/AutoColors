//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorFavDao](index.md)/[getAll](get-all.md)

# getAll

[androidJvm]\
abstract fun [getAll](get-all.md)(): [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md)&gt;

Obtiene todos los colores favoritos de la base de datos.

#### Return

Una lista mutable de todos los colores favoritos almacenados en la base de datos.
