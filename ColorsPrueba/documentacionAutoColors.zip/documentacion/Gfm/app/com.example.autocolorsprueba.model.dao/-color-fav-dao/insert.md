//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorFavDao](index.md)/[insert](insert.md)

# insert

[androidJvm]\
abstract fun [insert](insert.md)(vararg users: [ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md))

Inserta un color favorito en la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| users | El color favorito que se va a insertar en la base de datos. |
