//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorCocheDao](index.md)/[insert](insert.md)

# insert

[androidJvm]\
abstract fun [insert](insert.md)(coche: [ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md))

Inserta un color de coche en la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| coche | El color de coche que se va a insertar en la base de datos. |
