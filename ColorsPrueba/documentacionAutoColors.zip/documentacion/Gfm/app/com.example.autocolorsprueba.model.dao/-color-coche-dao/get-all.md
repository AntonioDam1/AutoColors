//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorCocheDao](index.md)/[getAll](get-all.md)

# getAll

[androidJvm]\
abstract fun [getAll](get-all.md)(): [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md)&gt;

Obtiene todos los colores de coche de la base de datos ordenados por porcentaje de coincidencia.

#### Return

Una lista mutable de todos los colores de coche almacenados en la base de datos, ordenados por porcentaje de coincidencia.
