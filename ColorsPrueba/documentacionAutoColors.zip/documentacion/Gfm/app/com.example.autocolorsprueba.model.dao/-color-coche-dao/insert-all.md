//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorCocheDao](index.md)/[insertAll](insert-all.md)

# insertAll

[androidJvm]\
abstract fun [insertAll](insert-all.md)(coches: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md)&gt;)

Inserta una lista de colores de coche en la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| coches | La lista de colores de coche que se van a insertar en la base de datos. |
