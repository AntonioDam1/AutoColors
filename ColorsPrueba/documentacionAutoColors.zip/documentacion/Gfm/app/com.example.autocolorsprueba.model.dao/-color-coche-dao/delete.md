//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorCocheDao](index.md)/[delete](delete.md)

# delete

[androidJvm]\
abstract fun [delete](delete.md)(coche: [ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md))

Elimina un color de coche de la base de datos.

#### Parameters

androidJvm

| | |
|---|---|
| coche | El color de coche que se va a eliminar de la base de datos. |
