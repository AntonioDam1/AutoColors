//[app](../../../index.md)/[com.example.autocolorsprueba.model.dao](../index.md)/[ColorCocheDao](index.md)/[deleteAll](delete-all.md)

# deleteAll

[androidJvm]\
abstract fun [deleteAll](delete-all.md)()

Elimina todos los colores de coche de la base de datos.
