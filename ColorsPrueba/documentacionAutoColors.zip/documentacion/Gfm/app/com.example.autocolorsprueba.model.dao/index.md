//[app](../../index.md)/[com.example.autocolorsprueba.model.dao](index.md)

# Package-level declarations

## Types

| Name | Summary |
|---|---|
| [ColorCocheDao](-color-coche-dao/index.md) | [androidJvm]<br>interface [ColorCocheDao](-color-coche-dao/index.md)<br>Interfaz que define las operaciones de acceso a datos para la entidad ColorCoche en la base de datos Room. |
| [ColorFavDao](-color-fav-dao/index.md) | [androidJvm]<br>interface [ColorFavDao](-color-fav-dao/index.md)<br>Interfaz que define las operaciones de acceso a datos para la entidad ColorFav en la base de datos Room. |
