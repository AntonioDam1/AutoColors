//[app](../../index.md)/[com.example.autocolorsprueba.httpClient](index.md)

# Package-level declarations

## Types

| Name | Summary |
|---|---|
| [HttpClient](-http-client/index.md) | [androidJvm]<br>class [HttpClient](-http-client/index.md)(listener: [HttpClient.HttpClientListener](-http-client/-http-client-listener/index.md))<br>Esta clase representa un cliente HTTP que realiza solicitudes al servidor y maneja las respuestas. Utiliza un HttpClientListener para notificar cuando se reciben los datos del servidor. |
