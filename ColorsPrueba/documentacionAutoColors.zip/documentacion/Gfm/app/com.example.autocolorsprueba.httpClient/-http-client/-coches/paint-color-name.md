//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[Coches](index.md)/[paintColorName](paint-color-name.md)

# paintColorName

[androidJvm]\
val [paintColorName](paint-color-name.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
