//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[Coches](index.md)/[model](model.md)

# model

[androidJvm]\
val [model](model.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
