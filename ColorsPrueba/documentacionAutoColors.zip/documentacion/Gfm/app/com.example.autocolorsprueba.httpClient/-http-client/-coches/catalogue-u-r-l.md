//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[Coches](index.md)/[catalogueURL](catalogue-u-r-l.md)

# catalogueURL

[androidJvm]\
val [catalogueURL](catalogue-u-r-l.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
