//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[Coches](index.md)/[hexadecimal](hexadecimal.md)

# hexadecimal

[androidJvm]\
val [hexadecimal](hexadecimal.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
