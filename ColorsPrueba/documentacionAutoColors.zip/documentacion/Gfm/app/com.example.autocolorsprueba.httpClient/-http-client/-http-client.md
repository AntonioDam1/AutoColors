//[app](../../../index.md)/[com.example.autocolorsprueba.httpClient](../index.md)/[HttpClient](index.md)/[HttpClient](-http-client.md)

# HttpClient

[androidJvm]\
constructor(listener: [HttpClient.HttpClientListener](-http-client-listener/index.md))

#### Parameters

androidJvm

| | |
|---|---|
| listener | El objeto que escucha las respuestas del servidor. |
