//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[HttpClientListener](index.md)

# HttpClientListener

[androidJvm]\
interface [HttpClientListener](index.md)

Interfaz que define un listener para recibir la lista de coches desde el cliente HTTP.

## Functions

| Name | Summary |
|---|---|
| [onCochesReceived](on-coches-received.md) | [androidJvm]<br>abstract fun [onCochesReceived](on-coches-received.md)(cochesList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[HttpClient.Coches](../-coches/index.md)&gt;)<br>Método llamado cuando se reciben los coches del cliente HTTP. |
