//[app](../../../../index.md)/[com.example.autocolorsprueba.httpClient](../../index.md)/[HttpClient](../index.md)/[HttpClientListener](index.md)/[onCochesReceived](on-coches-received.md)

# onCochesReceived

[androidJvm]\
abstract fun [onCochesReceived](on-coches-received.md)(cochesList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[HttpClient.Coches](../-coches/index.md)&gt;)

Método llamado cuando se reciben los coches del cliente HTTP.

#### Parameters

androidJvm

| | |
|---|---|
| cochesList | La lista de coches recibida desde el cliente HTTP. |
