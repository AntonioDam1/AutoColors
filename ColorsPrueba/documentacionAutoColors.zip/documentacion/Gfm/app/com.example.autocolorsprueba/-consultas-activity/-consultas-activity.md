//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ConsultasActivity](index.md)/[ConsultasActivity](-consultas-activity.md)

# ConsultasActivity

[androidJvm]\
constructor()
