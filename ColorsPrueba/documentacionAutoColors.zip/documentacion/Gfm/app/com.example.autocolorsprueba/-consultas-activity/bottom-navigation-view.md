//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ConsultasActivity](index.md)/[bottomNavigationView](bottom-navigation-view.md)

# bottomNavigationView

[androidJvm]\
lateinit var [bottomNavigationView](bottom-navigation-view.md): BottomNavigationView
