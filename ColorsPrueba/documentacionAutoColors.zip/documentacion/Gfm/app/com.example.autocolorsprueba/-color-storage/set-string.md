//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ColorStorage](index.md)/[setString](set-string.md)

# setString

[androidJvm]\
fun [setString](set-string.md)(value: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))

Establece el valor de la cadena almacenada.

#### Parameters

androidJvm

| | |
|---|---|
| value | La cadena de texto que se va a almacenar. |
