//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ColorStorage](index.md)/[getString](get-string.md)

# getString

[androidJvm]\
fun [getString](get-string.md)(): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)?

Obtiene el valor actual de la cadena almacenada.

#### Return

La cadena de texto almacenada, o null si no se ha establecido ninguna.
