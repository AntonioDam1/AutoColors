//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ColorCocheDetail](index.md)/[ColorCocheDetail](-color-coche-detail.md)

# ColorCocheDetail

[androidJvm]\
constructor()
