//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[MainActivity](index.md)/[REQUEST_CODE_GALLERY](-r-e-q-u-e-s-t_-c-o-d-e_-g-a-l-l-e-r-y.md)

# REQUEST_CODE_GALLERY

[androidJvm]\
val [REQUEST_CODE_GALLERY](-r-e-q-u-e-s-t_-c-o-d-e_-g-a-l-l-e-r-y.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 200
