//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[MainActivity](index.md)/[onCreateContextMenu](on-create-context-menu.md)

# onCreateContextMenu

[androidJvm]\
open override fun [onCreateContextMenu](on-create-context-menu.md)(menu: [ContextMenu](https://developer.android.com/reference/kotlin/android/view/ContextMenu.html), v: [View](https://developer.android.com/reference/kotlin/android/view/View.html), menuInfo: [ContextMenu.ContextMenuInfo](https://developer.android.com/reference/kotlin/android/view/ContextMenu.ContextMenuInfo.html)?)

Método para inflar el menú de el AlphaTileView.

#### Parameters

androidJvm

| | |
|---|---|
| menu | el menu a inflar |
| v | la view |
| menuInfo |
