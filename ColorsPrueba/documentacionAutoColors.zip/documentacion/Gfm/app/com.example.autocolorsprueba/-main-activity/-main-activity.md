//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[MainActivity](index.md)/[MainActivity](-main-activity.md)

# MainActivity

[androidJvm]\
constructor()
