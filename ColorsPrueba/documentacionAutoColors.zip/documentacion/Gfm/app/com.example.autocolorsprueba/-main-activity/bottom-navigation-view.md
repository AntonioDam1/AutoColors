//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[MainActivity](index.md)/[bottomNavigationView](bottom-navigation-view.md)

# bottomNavigationView

[androidJvm]\
lateinit var [bottomNavigationView](bottom-navigation-view.md): BottomNavigationView
