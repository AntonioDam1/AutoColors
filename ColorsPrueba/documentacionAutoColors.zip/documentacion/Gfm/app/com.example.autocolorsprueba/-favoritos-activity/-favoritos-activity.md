//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[FavoritosActivity](index.md)/[FavoritosActivity](-favoritos-activity.md)

# FavoritosActivity

[androidJvm]\
constructor()
