//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[FavoritosActivity](index.md)/[initRecyclerView](init-recycler-view.md)

# initRecyclerView

[androidJvm]\
fun [initRecyclerView](init-recycler-view.md)()

Método para iniciar el recyclerview de favoritos y pasarle las lista necesaria Cogemos los datos con un getAll en un hilo distinto Le decimos al adapter que es esa lista la que debe meter
