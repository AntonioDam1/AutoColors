//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[SplashActivity](index.md)/[SplashActivity](-splash-activity.md)

# SplashActivity

[androidJvm]\
constructor()
