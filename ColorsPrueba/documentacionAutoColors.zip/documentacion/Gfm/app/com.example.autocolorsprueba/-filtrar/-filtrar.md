//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[Filtrar](-filtrar.md)

# Filtrar

[androidJvm]\
constructor()
