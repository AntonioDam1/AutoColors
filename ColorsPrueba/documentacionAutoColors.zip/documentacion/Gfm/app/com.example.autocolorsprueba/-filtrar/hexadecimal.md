//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[hexadecimal](hexadecimal.md)

# hexadecimal

[androidJvm]\
lateinit var [hexadecimal](hexadecimal.md): [EditText](https://developer.android.com/reference/kotlin/android/widget/EditText.html)
