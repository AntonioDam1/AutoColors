//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[marca](marca.md)

# marca

[androidJvm]\
lateinit var [marca](marca.md): [EditText](https://developer.android.com/reference/kotlin/android/widget/EditText.html)
