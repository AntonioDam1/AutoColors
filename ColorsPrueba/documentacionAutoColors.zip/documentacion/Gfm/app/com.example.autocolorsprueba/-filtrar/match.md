//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[match](match.md)

# match

[androidJvm]\
lateinit var [match](match.md): [EditText](https://developer.android.com/reference/kotlin/android/widget/EditText.html)
