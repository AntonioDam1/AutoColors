//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[buscarColor](buscar-color.md)

# buscarColor

[androidJvm]\
fun [buscarColor](buscar-color.md)()

Función para comprobar que se han introducido bien los parámetros de búsqueda Nos saca un toast con los errores Finalmente ejecuta la consulta
