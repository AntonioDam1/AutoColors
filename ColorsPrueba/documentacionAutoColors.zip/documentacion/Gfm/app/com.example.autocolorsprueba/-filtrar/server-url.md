//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[serverUrl](server-url.md)

# serverUrl

[androidJvm]\
lateinit var [serverUrl](server-url.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
