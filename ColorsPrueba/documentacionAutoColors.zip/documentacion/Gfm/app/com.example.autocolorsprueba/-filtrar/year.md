//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[Filtrar](index.md)/[year](year.md)

# year

[androidJvm]\
lateinit var [year](year.md): [EditText](https://developer.android.com/reference/kotlin/android/widget/EditText.html)
