//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ColorMaps](index.md)/[onMyLocationClick](on-my-location-click.md)

# onMyLocationClick

[androidJvm]\
open override fun [onMyLocationClick](on-my-location-click.md)(p0: [Location](https://developer.android.com/reference/kotlin/android/location/Location.html))

Método que se invoca cuando el usuario hace clic en su ubicación en el mapa. Muestra un mensaje emergente que indica la latitud y longitud de la ubicación del usuario.

#### Parameters

androidJvm

| | |
|---|---|
| p0 | La ubicación del usuario en el mapa. |
