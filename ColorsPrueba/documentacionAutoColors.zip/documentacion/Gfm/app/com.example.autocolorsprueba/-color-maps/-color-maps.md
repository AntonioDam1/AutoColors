//[app](../../../index.md)/[com.example.autocolorsprueba](../index.md)/[ColorMaps](index.md)/[ColorMaps](-color-maps.md)

# ColorMaps

[androidJvm]\
constructor()
