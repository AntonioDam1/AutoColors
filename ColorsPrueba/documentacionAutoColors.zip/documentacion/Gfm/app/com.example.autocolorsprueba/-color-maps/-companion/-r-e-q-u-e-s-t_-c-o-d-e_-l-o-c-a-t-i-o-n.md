//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Companion](index.md)/[REQUEST_CODE_LOCATION](-r-e-q-u-e-s-t_-c-o-d-e_-l-o-c-a-t-i-o-n.md)

# REQUEST_CODE_LOCATION

[androidJvm]\
const val [REQUEST_CODE_LOCATION](-r-e-q-u-e-s-t_-c-o-d-e_-l-o-c-a-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0
