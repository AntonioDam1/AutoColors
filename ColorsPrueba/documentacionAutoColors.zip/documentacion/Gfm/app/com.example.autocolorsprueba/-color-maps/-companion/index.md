//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [REQUEST_CODE_LOCATION](-r-e-q-u-e-s-t_-c-o-d-e_-l-o-c-a-t-i-o-n.md) | [androidJvm]<br>const val [REQUEST_CODE_LOCATION](-r-e-q-u-e-s-t_-c-o-d-e_-l-o-c-a-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0 |
