//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Taller](index.md)/[name](name.md)

# name

[androidJvm]\
val [name](name.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| name | El nombre del taller. |
