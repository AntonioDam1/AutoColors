//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Taller](index.md)/[Taller](-taller.md)

# Taller

[androidJvm]\
constructor(name: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), latitude: [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html), longitude: [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html))

#### Parameters

androidJvm

| | |
|---|---|
| name | El nombre del taller. |
| latitude | La latitud del taller. |
| longitude | La longitud del taller. |
