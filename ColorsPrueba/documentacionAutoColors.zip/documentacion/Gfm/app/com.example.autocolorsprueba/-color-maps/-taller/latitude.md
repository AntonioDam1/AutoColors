//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Taller](index.md)/[latitude](latitude.md)

# latitude

[androidJvm]\
val [latitude](latitude.md): [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| latitude | La latitud del taller. |
