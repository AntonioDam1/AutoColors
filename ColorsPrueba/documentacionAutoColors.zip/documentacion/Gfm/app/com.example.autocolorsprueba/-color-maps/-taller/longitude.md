//[app](../../../../index.md)/[com.example.autocolorsprueba](../../index.md)/[ColorMaps](../index.md)/[Taller](index.md)/[longitude](longitude.md)

# longitude

[androidJvm]\
val [longitude](longitude.md): [Double](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-double/index.html)

#### Parameters

androidJvm

| | |
|---|---|
| longitude | La longitud del taller. |
