//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[testValidMatch](test-valid-match.md)

# testValidMatch

[androidJvm]\
fun [testValidMatch](test-valid-match.md)()

Comprobar que el macth este dentro de 0 y 100
