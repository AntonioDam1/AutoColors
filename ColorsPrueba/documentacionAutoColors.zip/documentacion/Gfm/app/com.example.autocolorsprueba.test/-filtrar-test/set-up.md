//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[setUp](set-up.md)

# setUp

[androidJvm]\
fun [setUp](set-up.md)()

Se supone que esto es para inicializar la clase
