//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[filtrar](filtrar.md)

# filtrar

[androidJvm]\
lateinit var [filtrar](filtrar.md): [Filtrar](../../com.example.autocolorsprueba/-filtrar/index.md)
