//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[testValidColorHex](test-valid-color-hex.md)

# testValidColorHex

[androidJvm]\
fun [testValidColorHex](test-valid-color-hex.md)()

Validación de colores hexadecimales
