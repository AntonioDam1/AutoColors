//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[testValidYear](test-valid-year.md)

# testValidYear

[androidJvm]\
fun [testValidYear](test-valid-year.md)()

Función que conprueba la validación de los años
