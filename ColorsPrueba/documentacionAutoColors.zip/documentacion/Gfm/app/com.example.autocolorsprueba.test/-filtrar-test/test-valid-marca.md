//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[testValidMarca](test-valid-marca.md)

# testValidMarca

[androidJvm]\
fun [testValidMarca](test-valid-marca.md)()

Validacion de marcas
