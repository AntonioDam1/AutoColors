//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[FiltrarTest](-filtrar-test.md)

# FiltrarTest

[androidJvm]\
constructor()
