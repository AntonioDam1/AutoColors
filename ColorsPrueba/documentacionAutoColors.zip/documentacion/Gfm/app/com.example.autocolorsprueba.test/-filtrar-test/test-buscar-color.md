//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[FiltrarTest](index.md)/[testBuscarColor](test-buscar-color.md)

# testBuscarColor

[androidJvm]\
fun [testBuscarColor](test-buscar-color.md)()
