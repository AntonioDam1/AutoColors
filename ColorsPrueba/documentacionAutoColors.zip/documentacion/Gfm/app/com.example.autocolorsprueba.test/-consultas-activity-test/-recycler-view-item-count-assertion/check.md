//[app](../../../../index.md)/[com.example.autocolorsprueba.test](../../index.md)/[ConsultasActivityTest](../index.md)/[RecyclerViewItemCountAssertion](index.md)/[check](check.md)

# check

[androidJvm]\
open fun [check](check.md)(view: [View](https://developer.android.com/reference/kotlin/android/view/View.html)?, noViewFoundException: &lt;Error class: unknown class&gt;?)
