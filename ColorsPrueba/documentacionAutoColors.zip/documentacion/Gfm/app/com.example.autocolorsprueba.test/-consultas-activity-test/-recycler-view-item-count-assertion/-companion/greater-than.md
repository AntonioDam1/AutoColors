//[app](../../../../../index.md)/[com.example.autocolorsprueba.test](../../../index.md)/[ConsultasActivityTest](../../index.md)/[RecyclerViewItemCountAssertion](../index.md)/[Companion](index.md)/[greaterThan](greater-than.md)

# greaterThan

[androidJvm]\
fun [greaterThan](greater-than.md)(expected: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)): [ConsultasActivityTest.RecyclerViewItemCountAssertion](../index.md)
