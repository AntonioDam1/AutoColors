//[app](../../../../index.md)/[com.example.autocolorsprueba.test](../../index.md)/[ConsultasActivityTest](../index.md)/[RecyclerViewItemCountAssertion](index.md)/[RecyclerViewItemCountAssertion](-recycler-view-item-count-assertion.md)

# RecyclerViewItemCountAssertion

[androidJvm]\
constructor(matcher: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
