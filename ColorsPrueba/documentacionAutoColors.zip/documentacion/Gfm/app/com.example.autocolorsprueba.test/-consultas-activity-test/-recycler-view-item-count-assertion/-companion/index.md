//[app](../../../../../index.md)/[com.example.autocolorsprueba.test](../../../index.md)/[ConsultasActivityTest](../../index.md)/[RecyclerViewItemCountAssertion](../index.md)/[Companion](index.md)

# Companion

object [Companion](index.md)

Crea una instancia de RecyclerViewItemCountAssertion con un valor esperado mayor que.

#### Return

Una instancia de RecyclerViewItemCountAssertion.

#### Parameters

androidJvm

| | |
|---|---|
| expected | El valor esperado. |

## Functions

| Name | Summary |
|---|---|
| [greaterThan](greater-than.md) | [androidJvm]<br>fun [greaterThan](greater-than.md)(expected: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)): [ConsultasActivityTest.RecyclerViewItemCountAssertion](../index.md) |
