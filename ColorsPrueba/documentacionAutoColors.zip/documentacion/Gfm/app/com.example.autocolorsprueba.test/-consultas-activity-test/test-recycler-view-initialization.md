//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ConsultasActivityTest](index.md)/[testRecyclerViewInitialization](test-recycler-view-initialization.md)

# testRecyclerViewInitialization

[androidJvm]\
fun [testRecyclerViewInitialization](test-recycler-view-initialization.md)()

Prueba para verificar la inicialización del RecyclerView.
