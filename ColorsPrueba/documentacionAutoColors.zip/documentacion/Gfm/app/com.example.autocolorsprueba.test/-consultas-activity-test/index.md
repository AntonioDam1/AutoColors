//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ConsultasActivityTest](index.md)

# ConsultasActivityTest

[androidJvm]\
class [ConsultasActivityTest](index.md)

Clase de prueba unitaria para la actividad ConsultasActivity.

## Constructors

| | |
|---|---|
| [ConsultasActivityTest](-consultas-activity-test.md) | [androidJvm]<br>constructor() |

## Types

| Name | Summary |
|---|---|
| [RecyclerViewItemCountAssertion](-recycler-view-item-count-assertion/index.md) | [androidJvm]<br>class [RecyclerViewItemCountAssertion](-recycler-view-item-count-assertion/index.md)(matcher: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))<br>Clase de aserción personalizada para contar elementos de RecyclerView. |

## Functions

| Name | Summary |
|---|---|
| [testRecyclerViewInitialization](test-recycler-view-initialization.md) | [androidJvm]<br>fun [testRecyclerViewInitialization](test-recycler-view-initialization.md)()<br>Prueba para verificar la inicialización del RecyclerView. |
