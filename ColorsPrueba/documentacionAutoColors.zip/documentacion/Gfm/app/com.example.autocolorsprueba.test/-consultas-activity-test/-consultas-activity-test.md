//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ConsultasActivityTest](index.md)/[ConsultasActivityTest](-consultas-activity-test.md)

# ConsultasActivityTest

[androidJvm]\
constructor()
