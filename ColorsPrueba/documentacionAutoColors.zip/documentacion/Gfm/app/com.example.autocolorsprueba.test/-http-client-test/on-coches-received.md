//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[HttpClientTest](index.md)/[onCochesReceived](on-coches-received.md)

# onCochesReceived

[androidJvm]\
open fun [onCochesReceived](on-coches-received.md)(cochesList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;&lt;Error class: unknown class&gt;&gt;)

Prueba para ver si se ha recibido algo
