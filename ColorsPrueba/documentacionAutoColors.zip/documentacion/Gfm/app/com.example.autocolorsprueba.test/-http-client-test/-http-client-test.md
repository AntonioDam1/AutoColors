//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[HttpClientTest](index.md)/[HttpClientTest](-http-client-test.md)

# HttpClientTest

[androidJvm]\
constructor()
