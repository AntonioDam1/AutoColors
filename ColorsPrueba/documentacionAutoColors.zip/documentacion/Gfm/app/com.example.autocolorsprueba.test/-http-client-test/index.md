//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[HttpClientTest](index.md)

# HttpClientTest

[androidJvm]\
class [HttpClientTest](index.md)

Clase para probar HttpClient, se prueba si el servidor envía datos

## Constructors

| | |
|---|---|
| [HttpClientTest](-http-client-test.md) | [androidJvm]<br>constructor() |

## Functions

| Name | Summary |
|---|---|
| [onCochesReceived](on-coches-received.md) | [androidJvm]<br>open fun [onCochesReceived](on-coches-received.md)(cochesList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;&lt;Error class: unknown class&gt;&gt;)<br>Prueba para ver si se ha recibido algo |
| [setUp](set-up.md) | [androidJvm]<br>fun [setUp](set-up.md)() |
| [testExecuteGetRequest](test-execute-get-request.md) | [androidJvm]<br>fun [testExecuteGetRequest](test-execute-get-request.md)(): &lt;Error class: unknown class&gt;<br>Se comprueba la conexión con el servidor y que devuelva datos |
