//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[HttpClientTest](index.md)/[testExecuteGetRequest](test-execute-get-request.md)

# testExecuteGetRequest

[androidJvm]\
fun [testExecuteGetRequest](test-execute-get-request.md)(): &lt;Error class: unknown class&gt;

Se comprueba la conexión con el servidor y que devuelva datos
