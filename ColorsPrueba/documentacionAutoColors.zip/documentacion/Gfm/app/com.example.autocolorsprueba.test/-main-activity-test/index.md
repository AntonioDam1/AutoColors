//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)

# MainActivityTest

[androidJvm]\
class [MainActivityTest](index.md)

## Constructors

| | |
|---|---|
| [MainActivityTest](-main-activity-test.md) | [androidJvm]<br>constructor() |

## Functions

| Name | Summary |
|---|---|
| [test_MainActivity_carga](test_-main-activity_carga.md) | [androidJvm]<br>fun [test_MainActivity_carga](test_-main-activity_carga.md)()<br>Test para probar si carga la MainActivity |
| [test_Navegacion_de_MainActivity_a_FavoritosActivity](test_-navegacion_de_-main-activity_a_-favoritos-activity.md) | [androidJvm]<br>fun [test_Navegacion_de_MainActivity_a_FavoritosActivity](test_-navegacion_de_-main-activity_a_-favoritos-activity.md)() |
| [test_Navegacion_de_MainActivity_a_FiltraryActivity](test_-navegacion_de_-main-activity_a_-filtrary-activity.md) | [androidJvm]<br>fun [test_Navegacion_de_MainActivity_a_FiltraryActivity](test_-navegacion_de_-main-activity_a_-filtrary-activity.md)()<br>Test para ir de la MainAcivity a la activity de filtrar |
| [test_Navegacion_de_MainActivity_a_MapasActivity](test_-navegacion_de_-main-activity_a_-mapas-activity.md) | [androidJvm]<br>fun [test_Navegacion_de_MainActivity_a_MapasActivity](test_-navegacion_de_-main-activity_a_-mapas-activity.md)()<br>Test para probar si va de MainActivity a MapasActivity |
