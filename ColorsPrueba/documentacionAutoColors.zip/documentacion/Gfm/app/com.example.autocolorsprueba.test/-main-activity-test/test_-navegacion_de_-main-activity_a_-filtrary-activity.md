//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)/[test_Navegacion_de_MainActivity_a_FiltraryActivity](test_-navegacion_de_-main-activity_a_-filtrary-activity.md)

# test_Navegacion_de_MainActivity_a_FiltraryActivity

[androidJvm]\
fun [test_Navegacion_de_MainActivity_a_FiltraryActivity](test_-navegacion_de_-main-activity_a_-filtrary-activity.md)()

Test para ir de la MainAcivity a la activity de filtrar
