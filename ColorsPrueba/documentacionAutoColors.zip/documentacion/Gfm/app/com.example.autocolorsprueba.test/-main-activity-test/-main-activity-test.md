//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)/[MainActivityTest](-main-activity-test.md)

# MainActivityTest

[androidJvm]\
constructor()
