//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)/[test_Navegacion_de_MainActivity_a_FavoritosActivity](test_-navegacion_de_-main-activity_a_-favoritos-activity.md)

# test_Navegacion_de_MainActivity_a_FavoritosActivity

[androidJvm]\
fun [test_Navegacion_de_MainActivity_a_FavoritosActivity](test_-navegacion_de_-main-activity_a_-favoritos-activity.md)()
