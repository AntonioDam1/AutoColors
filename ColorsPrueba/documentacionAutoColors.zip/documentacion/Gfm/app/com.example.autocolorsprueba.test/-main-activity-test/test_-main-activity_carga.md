//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)/[test_MainActivity_carga](test_-main-activity_carga.md)

# test_MainActivity_carga

[androidJvm]\
fun [test_MainActivity_carga](test_-main-activity_carga.md)()

Test para probar si carga la MainActivity
