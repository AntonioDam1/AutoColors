//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[MainActivityTest](index.md)/[test_Navegacion_de_MainActivity_a_MapasActivity](test_-navegacion_de_-main-activity_a_-mapas-activity.md)

# test_Navegacion_de_MainActivity_a_MapasActivity

[androidJvm]\
fun [test_Navegacion_de_MainActivity_a_MapasActivity](test_-navegacion_de_-main-activity_a_-mapas-activity.md)()

Test para probar si va de MainActivity a MapasActivity
