//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorMapsTest](index.md)/[ColorMapsTest](-color-maps-test.md)

# ColorMapsTest

[androidJvm]\
constructor()
