//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorMapsTest](index.md)/[setUp](set-up.md)

# setUp

[androidJvm]\
fun [setUp](set-up.md)()
