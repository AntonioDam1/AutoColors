//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorMapsTest](index.md)/[testOnMyLocationClick](test-on-my-location-click.md)

# testOnMyLocationClick

[androidJvm]\
fun [testOnMyLocationClick](test-on-my-location-click.md)()

Test para comprobar si devuelve la localización
