//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorMapsTest](index.md)

# ColorMapsTest

[androidJvm]\
class [ColorMapsTest](index.md)

Test para comprobar la clase de ColorMaps Uso RoboLectric para ejecutar pruebas unitarias

## Constructors

| | |
|---|---|
| [ColorMapsTest](-color-maps-test.md) | [androidJvm]<br>constructor() |

## Functions

| Name | Summary |
|---|---|
| [setUp](set-up.md) | [androidJvm]<br>fun [setUp](set-up.md)() |
| [testOnMyLocationClick](test-on-my-location-click.md) | [androidJvm]<br>fun [testOnMyLocationClick](test-on-my-location-click.md)()<br>Test para comprobar si devuelve la localización |
