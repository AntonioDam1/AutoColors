//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorCocheDetailTest](index.md)

# ColorCocheDetailTest

[androidJvm]\
class [ColorCocheDetailTest](index.md)

## Constructors

| | |
|---|---|
| [ColorCocheDetailTest](-color-coche-detail-test.md) | [androidJvm]<br>constructor() |

## Functions

| Name | Summary |
|---|---|
| [testViewsDisplayed](test-views-displayed.md) | [androidJvm]<br>fun [testViewsDisplayed](test-views-displayed.md)()<br>Prueba la clase ColorCocheDetail y que sus elementos estén visibles |
