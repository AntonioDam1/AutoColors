//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorCocheDetailTest](index.md)/[ColorCocheDetailTest](-color-coche-detail-test.md)

# ColorCocheDetailTest

[androidJvm]\
constructor()
