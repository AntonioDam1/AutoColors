//[app](../../../index.md)/[com.example.autocolorsprueba.test](../index.md)/[ColorCocheDetailTest](index.md)/[testViewsDisplayed](test-views-displayed.md)

# testViewsDisplayed

[androidJvm]\
fun [testViewsDisplayed](test-views-displayed.md)()

Prueba la clase ColorCocheDetail y que sus elementos estén visibles
