//[app](../../../../index.md)/[com.example.autocolorsprueba.database](../../index.md)/[CochesRoomDatabase](../index.md)/[Companion](index.md)/[getInstance](get-instance.md)

# getInstance

[androidJvm]\
fun [getInstance](get-instance.md)(context: [Context](https://developer.android.com/reference/kotlin/android/content/Context.html)): [CochesRoomDatabase](../index.md)

Función para obtener una instancia de la base de datos.

#### Return

Una instancia de la base de datos cocheRoomDatabase Hacemos fallbackDestructiveMigration para no tener que hacer migración de datos al cambiar datos de la columna de las tablas

#### Parameters

androidJvm

| |
|---|
| context |
