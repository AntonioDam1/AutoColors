//[app](../../../../index.md)/[com.example.autocolorsprueba.database](../../index.md)/[CochesRoomDatabase](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Functions

| Name | Summary |
|---|---|
| [getInstance](get-instance.md) | [androidJvm]<br>fun [getInstance](get-instance.md)(context: [Context](https://developer.android.com/reference/kotlin/android/content/Context.html)): [CochesRoomDatabase](../index.md)<br>Función para obtener una instancia de la base de datos. |
