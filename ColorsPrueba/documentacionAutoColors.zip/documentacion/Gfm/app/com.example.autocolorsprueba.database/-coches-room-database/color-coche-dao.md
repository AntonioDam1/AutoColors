//[app](../../../index.md)/[com.example.autocolorsprueba.database](../index.md)/[CochesRoomDatabase](index.md)/[colorCocheDao](color-coche-dao.md)

# colorCocheDao

[androidJvm]\
abstract fun [colorCocheDao](color-coche-dao.md)(): [ColorCocheDao](../../com.example.autocolorsprueba.model.dao/-color-coche-dao/index.md)
