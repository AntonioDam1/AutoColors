//[app](../../../index.md)/[com.example.autocolorsprueba.database](../index.md)/[CochesRoomDatabase](index.md)/[CochesRoomDatabase](-coches-room-database.md)

# CochesRoomDatabase

[androidJvm]\
constructor()
