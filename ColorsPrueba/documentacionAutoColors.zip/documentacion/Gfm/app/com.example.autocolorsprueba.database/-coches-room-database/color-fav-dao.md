//[app](../../../index.md)/[com.example.autocolorsprueba.database](../index.md)/[CochesRoomDatabase](index.md)/[colorFavDao](color-fav-dao.md)

# colorFavDao

[androidJvm]\
abstract fun [colorFavDao](color-fav-dao.md)(): [ColorFavDao](../../com.example.autocolorsprueba.model.dao/-color-fav-dao/index.md)
