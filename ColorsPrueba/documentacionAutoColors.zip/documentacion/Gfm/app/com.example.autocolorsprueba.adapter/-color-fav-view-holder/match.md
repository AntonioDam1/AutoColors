//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavViewHolder](index.md)/[match](match.md)

# match

[androidJvm]\
val [match](match.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
