//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavViewHolder](index.md)/[marca](marca.md)

# marca

[androidJvm]\
val [marca](marca.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
