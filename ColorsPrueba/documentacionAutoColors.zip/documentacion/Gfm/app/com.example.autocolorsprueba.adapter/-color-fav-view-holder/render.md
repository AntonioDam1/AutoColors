//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavViewHolder](index.md)/[render](render.md)

# render

[androidJvm]\
fun [render](render.md)(colorCoche: [ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md))

Método para establecer los datos del color del coche favorito en la interfaz de usuario.

#### Parameters

androidJvm

| | |
|---|---|
| colorCoche | El objeto ColorFav que contiene la información del color del coche favorito. |
