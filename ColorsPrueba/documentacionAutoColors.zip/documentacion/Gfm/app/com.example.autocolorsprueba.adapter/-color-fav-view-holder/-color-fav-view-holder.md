//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavViewHolder](index.md)/[ColorFavViewHolder](-color-fav-view-holder.md)

# ColorFavViewHolder

[androidJvm]\
constructor(view: [View](https://developer.android.com/reference/kotlin/android/view/View.html))
