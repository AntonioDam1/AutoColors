//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavViewHolder](index.md)/[codigo](codigo.md)

# codigo

[androidJvm]\
val [codigo](codigo.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
