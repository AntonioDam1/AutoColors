//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheViewHolder](index.md)/[nombrePintura](nombre-pintura.md)

# nombrePintura

[androidJvm]\
val [nombrePintura](nombre-pintura.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
