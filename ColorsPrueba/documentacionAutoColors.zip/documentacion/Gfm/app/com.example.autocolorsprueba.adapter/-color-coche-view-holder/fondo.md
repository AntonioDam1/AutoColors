//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheViewHolder](index.md)/[fondo](fondo.md)

# fondo

[androidJvm]\
val [fondo](fondo.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
