//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheViewHolder](index.md)/[ColorCocheViewHolder](-color-coche-view-holder.md)

# ColorCocheViewHolder

[androidJvm]\
constructor(view: [View](https://developer.android.com/reference/kotlin/android/view/View.html))
