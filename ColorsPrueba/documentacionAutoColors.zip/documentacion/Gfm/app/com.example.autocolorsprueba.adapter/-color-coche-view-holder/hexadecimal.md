//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheViewHolder](index.md)/[hexadecimal](hexadecimal.md)

# hexadecimal

[androidJvm]\
val [hexadecimal](hexadecimal.md): [TextView](https://developer.android.com/reference/kotlin/android/widget/TextView.html)
