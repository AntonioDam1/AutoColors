//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheViewHolder](index.md)/[render](render.md)

# render

[androidJvm]\
fun [render](render.md)(colorCoche: [ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md))

Método para establecer los datos del color del coche en la interfaz de usuario.

#### Parameters

androidJvm

| | |
|---|---|
| colorCoche | El objeto ColorFav que contiene la información del color del coche favorito. |
