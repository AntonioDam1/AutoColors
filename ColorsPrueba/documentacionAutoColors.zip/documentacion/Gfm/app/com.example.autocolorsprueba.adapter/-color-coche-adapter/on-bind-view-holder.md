//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheAdapter](index.md)/[onBindViewHolder](on-bind-view-holder.md)

# onBindViewHolder

[androidJvm]\
open override fun [onBindViewHolder](on-bind-view-holder.md)(holder: [ColorCocheViewHolder](../-color-coche-view-holder/index.md), position: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))

Actualiza el contenido de un ViewHolder en una posición específica.

#### Parameters

androidJvm

| | |
|---|---|
| holder | El ViewHolder que debe actualizarse. |
| position | La posición del elemento en la lista de datos. |
