//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheAdapter](index.md)/[ColorCocheAdapter](-color-coche-adapter.md)

# ColorCocheAdapter

[androidJvm]\
constructor(colorCocheList: [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md)&gt;)
