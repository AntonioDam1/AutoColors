//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheAdapter](index.md)/[getItemCount](get-item-count.md)

# getItemCount

[androidJvm]\
open override fun [getItemCount](get-item-count.md)(): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

Devuelve el número total de colores que hay en la lista.

#### Return

El número total de colores que hay en la lista.
