//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorCocheAdapter](index.md)/[colorCocheList](color-coche-list.md)

# colorCocheList

[androidJvm]\
val [colorCocheList](color-coche-list.md): [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorCoche](../../com.example.autocolorsprueba.model.entity/-color-coche/index.md)&gt;
