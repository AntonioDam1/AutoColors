//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavAdapter](index.md)/[ColorFavAdapter](-color-fav-adapter.md)

# ColorFavAdapter

[androidJvm]\
constructor(colorFavList: [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md)&gt;)
