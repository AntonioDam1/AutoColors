//[app](../../../index.md)/[com.example.autocolorsprueba.adapter](../index.md)/[ColorFavAdapter](index.md)/[colorFavList](color-fav-list.md)

# colorFavList

[androidJvm]\
val [colorFavList](color-fav-list.md): [MutableList](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)&lt;[ColorFav](../../com.example.autocolorsprueba.model.entity/-color-fav/index.md)&gt;
